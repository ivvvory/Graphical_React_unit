import { useRef } from 'react';
import { PointLight } from 'three';
import { useFrame } from '@react-three/fiber';

interface LightsProps {
  settings: {
    ambient: number;
    directional: number;
    pointLights: boolean;
  };
}

export function Lights({ settings }: LightsProps) {
  const pointLight1 = useRef<PointLight>(null);
  const pointLight2 = useRef<PointLight>(null);

  useFrame(({ clock }) => {
    if (settings.pointLights && pointLight1.current && pointLight2.current) {
      const time = clock.getElapsedTime();
      pointLight1.current.position.x = Math.sin(time) * 3;
      pointLight1.current.position.z = Math.cos(time) * 3;
      pointLight2.current.position.x = Math.sin(time + Math.PI) * 3;
      pointLight2.current.position.z = Math.cos(time + Math.PI) * 3;
    }
  });

  return (
    <>
      <ambientLight intensity={settings.ambient} />
      <directionalLight
        position={[5, 5, 5]}
        intensity={settings.directional}
        castShadow
      />
      {settings.pointLights && (
        <>
          <pointLight
            ref={pointLight1}
            position={[3, 0, 0]}
            intensity={1}
            color="#ff0000"
          />
          <pointLight
            ref={pointLight2}
            position={[-3, 0, 0]}
            intensity={1}
            color="#0000ff"
          />
        </>
      )}
    </>
  );
}