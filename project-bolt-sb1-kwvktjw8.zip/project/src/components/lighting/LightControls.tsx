import { useState } from 'react';

interface LightControlsProps {
  onUpdateLights: (lights: LightSettings) => void;
}

interface LightSettings {
  ambient: number;
  directional: number;
  pointLights: boolean;
}

export function LightControls({ onUpdateLights }: LightControlsProps) {
  const [settings, setSettings] = useState<LightSettings>({
    ambient: 0.5,
    directional: 1,
    pointLights: false,
  });

  const handleChange = (key: keyof LightSettings, value: number | boolean) => {
    const newSettings = { ...settings, [key]: value };
    setSettings(newSettings);
    onUpdateLights(newSettings);
  };

  return (
    <div className="absolute top-4 right-4 bg-gray-800 p-4 rounded-lg space-y-4 text-white">
      <div>
        <label className="block text-sm mb-1">Ambient Light</label>
        <input
          type="range"
          min="0"
          max="1"
          step="0.1"
          value={settings.ambient}
          onChange={(e) => handleChange('ambient', parseFloat(e.target.value))}
          className="w-full"
        />
      </div>
      <div>
        <label className="block text-sm mb-1">Directional Light</label>
        <input
          type="range"
          min="0"
          max="2"
          step="0.1"
          value={settings.directional}
          onChange={(e) => handleChange('directional', parseFloat(e.target.value))}
          className="w-full"
        />
      </div>
      <div>
        <label className="flex items-center space-x-2">
          <input
            type="checkbox"
            checked={settings.pointLights}
            onChange={(e) => handleChange('pointLights', e.target.checked)}
          />
          <span className="text-sm">Point Lights</span>
        </label>
      </div>
    </div>
  );
}