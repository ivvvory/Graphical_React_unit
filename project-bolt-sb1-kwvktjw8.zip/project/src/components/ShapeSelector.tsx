import { ShapeType } from '../types/shapes';

interface ShapeSelectorProps {
  onSelectShape: (shape: ShapeType) => void;
  currentShape: ShapeType;
}

const SHAPES: ShapeType[] = [
  'box', 'sphere', 'cylinder', 'cone', 'torus',
  'torusKnot', 'octahedron', 'dodecahedron', 'icosahedron',
  'tetrahedron', 'ring', 'circle', 'plane', 'capsule', 'tube'
];

export function ShapeSelector({ onSelectShape, currentShape }: ShapeSelectorProps) {
  return (
    <div className="absolute top-4 left-4 bg-gray-800 p-4 rounded-lg max-h-[calc(100vh-8rem)] overflow-y-auto">
      <h3 className="text-white font-bold mb-4">Select Shape</h3>
      <div className="space-y-2">
        {SHAPES.map((shape) => (
          <button
            key={shape}
            onClick={() => onSelectShape(shape)}
            className={`w-full px-4 py-2 rounded ${
              currentShape === shape
                ? 'bg-blue-500 text-white'
                : 'bg-gray-700 text-gray-200 hover:bg-gray-600'
            }`}
          >
            {shape.charAt(0).toUpperCase() + shape.slice(1)}
          </button>
        ))}
      </div>
    </div>
  );
}