import { Canvas } from '@react-three/fiber';
import { Scene } from './Scene';
import { Controls } from './Controls';
import { Suspense, useState } from 'react';
import { ShapeSelector } from './ShapeSelector';
import { LightControls } from './lighting/LightControls';
import { ShapeType } from '../types/shapes';

export function Renderer() {
  const [selectedShape, setSelectedShape] = useState<ShapeType>('box');
  const [lightSettings, setLightSettings] = useState({
    ambient: 0.5,
    directional: 1,
    pointLights: false,
  });

  return (
    <div className="w-full h-full relative">
      <Canvas
        camera={{ position: [0, 0, 5] }}
        style={{ background: '#1a1a1a' }}
      >
        <Suspense fallback={null}>
          <Scene
            selectedShape={selectedShape}
            lightSettings={lightSettings}
          />
          <Controls />
        </Suspense>
      </Canvas>
      
      <ShapeSelector
        onSelectShape={setSelectedShape}
        currentShape={selectedShape}
      />
      
      <LightControls
        onUpdateLights={setLightSettings}
      />
    </div>
  );
}