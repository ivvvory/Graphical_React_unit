import { useRef } from 'react';
import { Mesh } from 'three';
import { useFrame } from '@react-three/fiber';
import { ShapeConfig } from '../../types/shapes';

export function Shape({ type, color, metalness = 0.5, roughness = 0.5, scale = 1 }: ShapeConfig) {
  const meshRef = useRef<Mesh>(null);

  useFrame((state, delta) => {
    if (meshRef.current) {
      meshRef.current.rotation.x += delta * 0.2;
      meshRef.current.rotation.y += delta * 0.3;
    }
  });

  const getGeometry = () => {
    switch (type) {
      case 'box':
        return <boxGeometry args={[1, 1, 1]} />;
      case 'sphere':
        return <sphereGeometry args={[0.7, 32, 32]} />;
      case 'cylinder':
        return <cylinderGeometry args={[0.5, 0.5, 1.5, 32]} />;
      case 'cone':
        return <coneGeometry args={[0.7, 1.5, 32]} />;
      case 'torus':
        return <torusGeometry args={[0.5, 0.2, 16, 32]} />;
      case 'torusKnot':
        return <torusKnotGeometry args={[0.5, 0.2, 128, 16]} />;
      case 'octahedron':
        return <octahedronGeometry args={[0.7]} />;
      case 'dodecahedron':
        return <dodecahedronGeometry args={[0.7]} />;
      case 'icosahedron':
        return <icosahedronGeometry args={[0.7]} />;
      case 'tetrahedron':
        return <tetrahedronGeometry args={[0.7]} />;
      case 'ring':
        return <ringGeometry args={[0.3, 0.7, 32]} />;
      case 'circle':
        return <circleGeometry args={[0.7, 32]} />;
      case 'plane':
        return <planeGeometry args={[1, 1]} />;
      case 'capsule':
        return <capsuleGeometry args={[0.3, 0.7, 4, 8]} />;
      case 'tube':
        return <tubeGeometry args={[new THREE.CatmullRomCurve3([
          new THREE.Vector3(-0.5, -0.5, 0),
          new THREE.Vector3(0.5, 0.5, 0)
        ]), 64, 0.1]} />;
      default:
        return <boxGeometry />;
    }
  };

  return (
    <mesh ref={meshRef} scale={scale}>
      {getGeometry()}
      <meshStandardMaterial
        color={color}
        metalness={metalness}
        roughness={roughness}
      />
    </mesh>
  );
}