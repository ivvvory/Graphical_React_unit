import { useState } from 'react';
import { Shape } from './shapes/Shape';
import { Lights } from './lighting/Lights';
import { ShapeType } from '../types/shapes';

interface SceneProps {
  selectedShape: ShapeType;
  lightSettings: {
    ambient: number;
    directional: number;
    pointLights: boolean;
  };
}

export function Scene({ selectedShape, lightSettings }: SceneProps) {
  return (
    <>
      <Lights settings={lightSettings} />
      <Shape
        type={selectedShape}
        color="#4287f5"
        metalness={0.5}
        roughness={0.5}
        scale={1}
      />
    </>
  );
}