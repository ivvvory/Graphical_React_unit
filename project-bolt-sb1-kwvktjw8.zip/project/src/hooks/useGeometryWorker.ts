import { useEffect, useCallback } from 'react';

export function useGeometryWorker() {
  const worker = new Worker(new URL('../workers/geometryWorker.ts', import.meta.url), {
    type: 'module'
  });

  const processGeometry = useCallback((vertices: Float32Array, indices: Uint16Array) => {
    return new Promise((resolve) => {
      worker.onmessage = (e) => {
        resolve(e.data);
      };
      worker.postMessage({ vertices, indices });
    });
  }, [worker]);

  useEffect(() => {
    return () => {
      worker.terminate();
    };
  }, [worker]);

  return { processGeometry };
}