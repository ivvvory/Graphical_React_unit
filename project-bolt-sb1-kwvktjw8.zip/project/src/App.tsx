import React from 'react';
import { Renderer } from './components/Renderer';
import { Cube } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gray-900 flex flex-col">
      <header className="bg-gray-800 text-white p-4">
        <div className="container mx-auto flex items-center gap-2">
          <Cube className="w-6 h-6" />
          <h1 className="text-xl font-bold">3D WebGL Renderer</h1>
        </div>
      </header>
      
      <main className="flex-1 container mx-auto p-4">
        <div className="bg-gray-800 rounded-lg overflow-hidden h-[calc(100vh-8rem)] relative">
          <Renderer />
        </div>
      </main>
      
      <footer className="bg-gray-800 text-gray-400 p-4">
        <div className="container mx-auto text-center">
          <p>Interactive 3D Renderer with Multiple Shapes and Custom Lighting</p>
        </div>
      </footer>
    </div>
  );
}

export default App;