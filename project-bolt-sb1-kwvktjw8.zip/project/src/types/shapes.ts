export type ShapeType =
  | 'box'
  | 'sphere'
  | 'cylinder'
  | 'cone'
  | 'torus'
  | 'torusKnot'
  | 'octahedron'
  | 'dodecahedron'
  | 'icosahedron'
  | 'tetrahedron'
  | 'ring'
  | 'circle'
  | 'plane'
  | 'capsule'
  | 'tube';

export interface ShapeConfig {
  type: ShapeType;
  color: string;
  metalness?: number;
  roughness?: number;
  scale?: number;
}