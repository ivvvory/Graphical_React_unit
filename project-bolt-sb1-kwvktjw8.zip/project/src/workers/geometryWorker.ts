// Web Worker for geometry calculations
self.onmessage = (e) => {
  const { vertices, indices } = e.data;
  
  // Perform heavy geometry calculations here
  const computeNormals = () => {
    const normals = new Float32Array(vertices.length);
    // Calculate vertex normals
    for (let i = 0; i < indices.length; i += 3) {
      // ... normal calculations
    }
    return normals;
  };

  const result = computeNormals();
  self.postMessage(result);
};